# Portfolio
@mikemgm

**Link to GitHub repo:** https://github.com/mikemgm/M.M.-Portfolio/tree/master ****** ADD live web********

**Q&A:** 

1- The beginning of one of the most crucial technologies since the invention of the wheel came from the minds of several individuals. British CERN employee Tim Berners-Lee one day saw that the European Organization Nuclear Research team needed a better way to communicate and share information. He then went on to invent the WorldWideWeb. After that took off several technological companies started creating browsers for www. such as Firefox, Internet Explorer and Netscape Navigator. 

Years after Netscape developer, Dave Winer released a XML based format that essentially created RSS feeds. Blogs and Podcasts rely on RSS feed. 
Another major breakthrough was the use of e-mail. No longer where people going to write cards for enormous distances and waiting times. 
After e-mail a big discovery was the access to audio files and how to share them. MP3 made its way to civilizations and the joy of iPods. We said goodbye to tapes or cd players and the rest is history. 


2- The internet backbone is made up of several networks known as NSP(network services providers) Routers are connected to networks to deliver the packets. When a router receives a packet from the IP protocol layer, it checks its IP Address and if it matches it will send it to the matching router. If the computer can’t find the IP Address then it can find the DNS (domain name service) The DNS basically keeps track of all the IP Address that go through the servers online. 
So when you are accessing the internet you have to put in a URL at the top of the browser, the start of this URL is most likely HTTP. This is what enables communication with the online world. Once you search that URL the computer checks for an IP address using the DNS server. If it connects to the server it sends out an HTTP and if it matches then it is brought back to your computer with a connection and the webpage is displayed on your screen. 

3-Like mentioned before, I think the invention of the internet was one of those mega jumps for human civilization. It has benefited us greatly and is one of the major reasons why our world today is “global.” Yes, it is not all good because somehow people will find ways to misuse this great tool but overall the good it has brought our society outlasts any damage done by it. The technology that enables us to not leave the house and order groceries, food, appliances, and much more, is remarkable. One can only think what the next big discovery will be, but one thing is for sure, the internet will be involved in some way when it happens.









**Screenshots:** 

**

<img src="docs/wire-frame.png.jpg" width="500" height="500"> 


